# Sales and Return Rates Performance Analysis

## Description
This project analyzes the sales performance and return rates of a retail company over the past year. The dashboard provides visualizations that helps to understanding return rate trends, low-performing products, and states with the highest return rates.

## Tableau Public Link
View the dashboard on Tableau Public
https://public.tableau.com/app/profile/george.morrison8861/viz/Data_Visualization_Sprint5_Project/ExecutiveSalesDashboard?publish=yes
View the storyboard on Tableau Public
https://public.tableau.com/app/profile/george.morrison8861/viz/Data_Visualization_Sprint5_Project/Analyzingandmeasureingreturns_?publish=yes

## Instructions
1. Open the link to view the dashboard.
2. Navigate through the different tabs to explore various visualizations.
3. Use the filters provided to interact with the data and gain deeper insights.
4. For any questions or further information, please refer to the contact details provided in the dashboard.
	Email address: morrisgeorg@outlook.com
